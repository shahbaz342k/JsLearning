1. Gemini Organics : It is a online grocery store where user can buy online groceries. 
In this project, I worked as frontend developer at react i worked different types of 
modules products module,
cart module,
checkout order module where i used stripe payment gateway for the payment , 
orders module and users module

2. Khushi: It is NGOs Project adminstrator manage updates about NGOS.
i worked as a backend developer on this project. I worked on different type of modules like 
 posts managing module, contact form module , and donation form module
where i used razorpay payment gateway for the payment.

3. VASANT VALLEY: Its a school project wehre adminstrator manage all the activities about school. I worked as 
backend developer
i worked on contact form and career form module

4. HPS: HPS is a plastic surgery clinic website,  Where user can fix an appointment online. 
In this project i worked on the appointment form module. 

5. YOGAKSHEMA: It is providing an online classes for yoga to the user who is
registering with payment. Its a maintenence project, i worked admin panel module admin 
manage all the users data. 

6. DASHEVENTS : Its events management system. Where i user can fix their events online like party, marriage etc. 
I worked for managing the events form module.

7. YARRA VALLEY IMPEX : Yarra Valley Impex is a online ecommerce site. where user
can buy different types of tea online. i worked for products managing and payment gateway module in this project.

